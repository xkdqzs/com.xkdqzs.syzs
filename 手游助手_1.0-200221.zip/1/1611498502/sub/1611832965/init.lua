name="关于手游助手"
template="tool"
