template="tool"
name="关于手游助手"
